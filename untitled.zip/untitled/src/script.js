
// Load all tasks
async function loadTasks() {

    const response = await fetch("/tasks");
    const tasks = await response.json();

    const taskList = document.getElementById("taskList");

    taskList.innerHTML = "";

    let completed = 0;

    tasks.forEach(task => {

        const li = document.createElement("li");

        const name = document.createElement("span");

        name.textContent =
            task.title + " (" + task.minutes + " minutes)";

        if (task.completed) {
            name.classList.add("completed");
            completed++;
        }

        const doneBtn = document.createElement("button");

        doneBtn.textContent = task.completed ? "Undo" : "Complete";

        doneBtn.onclick = () => completeTask(task.id);

        const deleteBtn = document.createElement("button");

        deleteBtn.textContent = "Delete";

        deleteBtn.onclick = () => deleteTask(task.id);

        li.appendChild(name);
        li.appendChild(doneBtn);
        li.appendChild(deleteBtn);

        taskList.appendChild(li);
    });

    // Update dashboard
    document.getElementById("totalTasks").textContent =
        tasks.length;

    document.getElementById("completedTasks").textContent =
        completed;

    let percentage = tasks.length === 0
        ? 0
        : Math.round((completed / tasks.length) * 100);

    document.getElementById("progress").textContent =
        percentage + "%";
}


// Add new task
async function addTask() {

    const title = document.getElementById("taskName").value.trim();

    const minutes = Number(
        document.getElementById("studyTime").value
    );

    if (title === "" || !Number.isInteger(minutes) || minutes <= 0) {
        alert("Enter a task name and valid study time!");
        return;
    }

    const response = await fetch("/add_task", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            title: title,
            minutes: minutes
        })
    });

    if (!response.ok) {
        alert("Unable to add task");
        return;
    }

    document.getElementById("taskName").value = "";
    document.getElementById("studyTime").value = "";

    loadTasks();
}


// Complete or undo task
async function completeTask(id) {

    await fetch("/complete_task/" + id, {
        method: "POST"
    });

    loadTasks();
}


// Delete task
async function deleteTask(id) {

    if (!confirm("Delete this task?")) {
        return;
    }

    await fetch("/delete_task/" + id, {
        method: "DELETE"
    });

    loadTasks();
}


// Pomodoro Timer
let timeLeft = 25 * 60;
let timerInterval = null;

function updateTimer() {

    let minutes = Math.floor(timeLeft / 60);
    let seconds = timeLeft % 60;

    document.getElementById("timer").textContent =
        String(minutes).padStart(2, "0") + ":" +
        String(seconds).padStart(2, "0");
}


// Start timer
function startTimer() {

    if (timerInterval !== null || timeLeft <= 0) {
        return;
    }

    timerInterval = setInterval(() => {

        timeLeft--;

        updateTimer();

        if (timeLeft <= 0) {

            clearInterval(timerInterval);
            timerInterval = null;

            alert("Great job! Your study session is complete!");
        }

    }, 1000);
}


// Pause timer
function pauseTimer() {

    clearInterval(timerInterval);
    timerInterval = null;
}


// Reset timer
function resetTimer() {

    pauseTimer();

    timeLeft = 25 * 60;

    updateTimer();
}


// Start application
updateTimer();
loadTasks();
